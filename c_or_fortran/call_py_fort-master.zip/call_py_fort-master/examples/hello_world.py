def say(STATE):
    print(STATE["message"])
