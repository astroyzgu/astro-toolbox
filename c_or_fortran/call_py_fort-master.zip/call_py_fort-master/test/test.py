def test_function(STATE):
    print("This is a testing function")
